# importing all required libraries
import dash
import dash_core_components as dcc
import dash_html_components as html
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import plotly.graph_objs as go

app = dash.Dash(__name__)
# reading the csv data set file to pandas data frame
df = pd.read_csv('IMDB-Movie-Data.csv')

# creating a html Div so I can put sliders text box and graph in it and control how my app looks like
app.layout = html.Div(

    [
        # first html tag
        html.H1('An Interactive Explorer For IMDB DATA!',
                # applying css to h1 tag
                style=
                {

                    'textAlign': 'center',
                    'color': '#456FBV'
                }
                ),
        # again a simple sub div to add text
        html.Div('Interact with Widgets to Update the Graph!!!',
                 # styling of text
                 style=
                 {
                     'textAlign': 'center',
                     'color': 'red'

                 }),  # adding a line spaces between elements
        html.Br(),
        html.Br(),

        # this div will show line above first slider that says minimun no of votes
        html.Div(id='votes-label'),
        # now here I'm using dash core component. I should  always reffers this with dash_core_components as I
        # have defined dash_core_components as dcc so , I'm  calling like dcc.Slider and setting id its min max
        # value with no of steps and initial value
        dcc.Slider(id='votes-slider', min=61, max=1791916, value=500000, step=10000,
                   ),
        # again two line spaces
        html.Br(),
        html.Br(),

        # same as above we are creating a slider here for revenue
        html.Div(id='revenue-label'),
        dcc.Slider(id='revenue-slider', min=0.0, max=936.63, value=100, step=5,

                   ),

        html.Br(),
        html.Br(),

        # now here creating drop down menu to select move genre
        html.Label("Select Genre"),
        # I have set its id and all list in it with value assigned to each list member so we can know which element is selected
        dcc.Dropdown(id='genre-select',
                     options=[

                         {'label': 'All', 'value': ''},
                         {'label': 'Action', 'value': 'Action'},
                         {'label': 'Comedy', 'value': 'Comedy'},
                         {'label': 'Drama', 'value': 'Drama'},
                         {'label': 'History', 'value': 'History'},
                         {'label': 'War', 'value': 'War'},
                         {'label': 'Biography', 'value': 'Biography'},
                         {'label': 'Crime', 'value': 'Crime'},
                         {'label': 'Animation', 'value': 'Animation'},
                         {'label': 'Fantasy', 'value': 'Fantasy'},
                         {'label': 'Horror', 'value': 'Horror'},
                         {'label': 'Mystery', 'value': 'Mystery'},
                         {'label': 'Sci-Fi', 'value': 'Sci-Fi'},
                         {'label': 'Romance', 'value': 'Romance'},
                         {'label': 'Mystery', 'value': 'Mystery'},
                         {'label': 'Family', 'value': 'Family'},
                         {'label': 'Musical', 'value': 'Musical'},
                         {'label': 'Thriller', 'value': 'Thriller'},
                         {'label': 'Western', 'value': 'Western'}

                     ],
                     # initially we set its value '' so on screen we se ALL already selected in drop down menu
                     value=''),
        html.Br(),
        html.Br(),
        # again a slider for starting year
        html.Label(id="syear"),
        dcc.Slider(id='slider-syear', min=2006, max=2010, value=2006, step=1),
        html.Br(),
        html.Br(),

        # slider for ending year
        html.Label(id="eyear"),
        dcc.Slider(id='slider-eyear', min=2011, max=2016, value=2016, step=1),
        html.Br(),
        html.Br(),
        # slider for rating
        html.Label(id="rating"),
        dcc.Slider(id='slider-rating', min=0, max=10, value=5, step=1),
        html.Br(),
        html.Br(),
        # now here I'm creating a input box where user will enter director name so i can filter dataset
        # initial value is set to ''
        html.Label("Director Name Contains"),
        html.Br(),
        dcc.Input(id='director', placeholder="Enter Name", type='text', value=''),

        html.Br(),
        html.Br(),

        # another input box for cast
        html.Label("Cast Names Contains"),
        html.Br(),
        dcc.Input(id='cast', placeholder="Enter Name", type='text', value=''),

        html.Br(),
        html.Br(),

        # drop down menu for x-axis as I created above for genre
        # inital value is set to year
        html.Label("X Axis"),
        dcc.Dropdown(id='x-axis',
                     options=[

                         {'label': 'Year', 'value': 'Year'},
                         {'label': 'Runtime (Minutes)', 'value': 'Runtime (Minutes)'},
                         {'label': 'Rating', 'value': 'Rating'},
                         {'label': 'Votes', 'value': 'Votes'},
                         {'label': 'Revenue (Millions)', 'value': 'Revenue (Millions)'},
                         {'label': 'Metascore', 'value': 'Metascore'}

                     ],
                     multi=False,
                     value='Year'),

        html.Br(),
        html.Br(),
        # drop down for y axis initial value set to Revenue
        html.Label("Y Axis"),
        dcc.Dropdown(id='y-axis',
                     options=[

                         {'label': 'Year', 'value': 'Year'},
                         {'label': 'Runtime (Minutes)', 'value': 'Runtime (Minutes)'},
                         {'label': 'Rating', 'value': 'Rating'},
                         {'label': 'Votes', 'value': 'Votes'},
                         {'label': 'Revenue (Millions)', 'value': 'Revenue (Millions)'},
                         {'label': 'Metascore', 'value': 'Metascore'}

                     ],
                     multi=False,
                     value='Revenue (Millions)'),
        html.Br(),
        html.Br(),

        # this is an empty div here my graph will be shown provided by callback functions
        html.Div(id='Out')

    ]

)




# this is a call back function for the graph
@app.callback(
    # this line indicates that I only have to return data to element with id ='Out'
    dash.dependencies.Output(component_id='Out', component_property='children'),
    # and these lines are indicating that I have have to trigger for the elements with ids (as defined below) and get there value
    [dash.dependencies.Input(component_id='votes-slider', component_property='value'),
     dash.dependencies.Input(component_id='revenue-slider', component_property='value'),
     dash.dependencies.Input(component_id='genre-select', component_property='value'),
     dash.dependencies.Input(component_id='slider-syear', component_property='value'),
     dash.dependencies.Input(component_id='slider-eyear', component_property='value'),
     dash.dependencies.Input(component_id='slider-rating', component_property='value'),
     dash.dependencies.Input(component_id='director', component_property='value'),
     dash.dependencies.Input(component_id='cast', component_property='value'),
     dash.dependencies.Input(component_id='x-axis', component_property='value'),
     dash.dependencies.Input(component_id='y-axis', component_property='value'),

     ])
# after pressed this funtion runs. The parameters are exactly the same as I have defined input elemets above like votes-slider
def update_output(votes, revenue, genre, syear, eyear, srating, director, cast, xaxis, yaxis):
    # first of all I just put pandas data frame into new variable dfn so we never change original data frame
    dfn = df
    '''first of all I need  check for the both input box values and genre slider value as they could have '' or a real value
    '''
    # if value is "" means so we put  genref=str() and filter the column of data frame in this way we get everything
    if (str(genre) == ""):    # str: this function specifies the string to be searched
        genref = str()
        dfn = dfn[dfn['Genre'].str.contains(genref)]    #str.contaies() return series or index of boolen
     # but if value is not "" means user has enter something so we put  genref=genre and pass genref to dataframe to filter the column
    else:
        genref = genre
        dfn = dfn[dfn['Genre'].str.contains(genref)]

        # same here for these two as well
    if (str(director) == ""):
        directorf = str()
        dfn = dfn[dfn['Director'].str.contains(directorf)]
    else:
        directorf = str(director).capitalize()
        dfn = dfn[dfn['Director'].str.contains(directorf)]

    if (str(cast) == ""):
        castf = str()
        dfn = dfn[dfn['Actors'].str.contains(castf)]
    else:
        castf = cast
        castf = str(cast).capitalize()
        dfn = dfn[dfn['Actors'].str.contains(castf)]

     # here I apply mask. Masking is the way to filer the dataframe so I filter it for votes revenues ,years and rating
    mask = (dfn['Votes'] > int(votes)) & (dfn['Revenue (Millions)'] > int(revenue)) & (dfn['Year'] > int(syear)) & (
            dfn['Year'] < int(eyear)) & (dfn['Rating'] > int(srating))
    dfn = dfn.loc[mask]

    # here i'm creating a scatter graph of the dataframe and  it filtered and returning it to the div elemetent with id=Out
    # as I have defined in call back that we'll return data to the div element with id=Out.
    return dcc.Graph(id="sample-graph", figure={
        'data': [
            # set x axis and y axis from the dataframe column
            go.Scatter(x=dfn[xaxis], y=dfn[yaxis],
                       # this is the text we see on graph when we however on a value
                       text=(dfn['Title']) + "\n" + (dfn['Genre']) + "\n" + (dfn['Director']) + "\n" + (dfn['Actors']),

                       hoverinfo='text',

                       showlegend=False,

                       mode='markers'
                       ),

            # {'x':x,'y':y,'type':'bar','name':'First Chart'},

        ],
        # here we set title and axises names
        'layout': {
            # 'plot_bgcolor':'yellow','paper_bgcolor':'pink',

            'title': 'Movies Graph',
            'xaxis': {
                'title': xaxis
            },
            'yaxis': {
                'title': yaxis
            }
        }
    })



##All these call backs belong to the labels above a sliders so when  I change slider it changes values immediately like
##Minimum Rating : 5 , Minimum Rating : 6 .....................'''


# set votes
@app.callback(
    dash.dependencies.Output('votes-label', 'children'),
    [dash.dependencies.Input('votes-slider', 'value')
     ])
def update_output(value):
    return 'Minimum No of Votes {} '.format(value)


# set revenue
@app.callback(
    dash.dependencies.Output('revenue-label', 'children'),
    [dash.dependencies.Input('revenue-slider', 'value')
     ])
def update_output(value):
    return 'Minimum amount of Revenue {} (Millions) '.format(value)


# set start year
@app.callback(
    dash.dependencies.Output('syear', 'children'),
    [dash.dependencies.Input('slider-syear', 'value')
     ])
def update_output(value):
    return 'Year Released: {} '.format(value)


# set end year
@app.callback(
    dash.dependencies.Output('eyear', 'children'),
    [dash.dependencies.Input('slider-eyear', 'value')
     ])
def update_output(value):
    return 'End Year Released: {} '.format(value)


# rating
@app.callback(
    dash.dependencies.Output('rating', 'children'),
    [dash.dependencies.Input('slider-rating', 'value')
     ])
def update_output(value):
    return 'Minimum Rating : {}  '.format(value)


if __name__ == '__main__':

    app.server.run()
